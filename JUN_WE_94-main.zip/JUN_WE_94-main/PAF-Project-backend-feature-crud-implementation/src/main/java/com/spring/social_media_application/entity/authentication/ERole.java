package com.spring.social_media_application.entity.authentication;

public enum ERole {
  ROLE_USER,
  ROLE_ADMIN
}
