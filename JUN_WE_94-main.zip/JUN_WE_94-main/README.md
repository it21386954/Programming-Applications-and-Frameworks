# PAF
# Real E-state

Welcome to Real E-state! This repository contains the source code for the Real E-state project, a web application for managing real estate properties.

## Getting Started

To get started with this project, follow the steps below:

### Prerequisites

Make sure you have the following installed on your machine:

- Node.js and npm (Node Package Manager)
- Java Development Kit (JDK)
- Visual Studio Code (or any preferred code editor)

### Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/PAF-IT3030/JUN_WE_94.git

2. Navigate to the project directory
   ```bash
   cd real-estate

3. Install dependencies:
 
   ```bash
   npm install

### Running the Project
### Frontend (React)

   To start the frontend development server, run
    ```bash
    npm start


### Backend (Spring Boot)
### To run the backend server using Spring Boot, follow these steps:
  
 1. Open the project in Visual Studio Code:
     ```bash
     code .

## User Interface :iphone:
These are some pictures of the app's user interface :<br /><br />
![ic_launcher](https://github.com/it21386954/MAD-Project/assets/99165392/390cad54-90ba-4583-9dcb-93b949ea3b59)
![20220619_Sign In Activity](https://github.com/it21386954/MAD-Project/assets/99165392/0ed660e1-8d6d-4fa1-967b-be9e14e24a99)
![20220619_Sign Up Activity](https://github.com/it21386954/MAD-Project/assets/99165392/a3b6904f-e9c7-4073-839f-4681d0ef304d)
![20220619_Transaction Fragment](https://github.com/it21386954/MAD-Project/assets/99165392/f4bf4532-02a5-4efe-85c5-8335444c7cfb)
![20220619_Transaction Details Income](https://github.com/it21386954/MAD-Project/assets/99165392/615c78f2-8246-4e0c-a110-0b606c83c62a)
![20220627_Export Activity](https://github.com/it21386954/MAD-Project/assets/99165392/bee3bb67-d9fd-4a77-8458-6b4dc816688d)

<br /><br />   

